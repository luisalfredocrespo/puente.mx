 <div class="fullwidth-section dt-sc-parallax-section appointment-parallax dark-bg" style="background-position: 20% 3px;">
                    <div class="fullwidth-bg">
                    	<div class="parallax-spacing">
                    		<div class="container">
                            	<h3 class="border-title jmy_web_div" data-page="nosotros" id="hola75"data-editor="no">
<?php $this->pnt('hola75','Reserva tu cita con anticipación '); ?></h3>
                                <div class="aligncenter">
                                	<a href="<?php echo RUTA_ACTUAL; ?>contacto" class="appointment-btn btn-eff2 jmy_web_div" data-page="nosotros" id="hola76"data-editor="no">
<?php $this->pnt('hola76','Reserva tu cita con anticipación '); ?>
</a>
                              	</div>
                            </div>
                        </div>
                   	</div>

  </div>

<div class="container"><!-- Container -->
               <h2 class="border-title aligncenter jmy_web_div" data-page="nosotros" id="hola77"data-editor="no">
<?php $this->pnt('hola77','Salon Evolution'); ?>
</h2>
                 <font color=black><h4 class="aligncenter jmy_web_div" data-page="nosotros" id="hola78"data-editor="no">
<?php $this->pnt('hola78','Abre sus puertas el 10 de agosto 2002 en calle 11 # 47 colonia Espartaco Coyoacán y inicia con el nombre de estética capricornio el 22 de octubre cambia de dirección avenida 4 # 87 colonia Espartaco Coyoacán el cual a estado trabajando de la mano con los productos ALFA PARF (ITALIANOS) , tec Italy (ilaliano) , salerm (español) el cual nos accesoramos '); ?>
</h4></font>
         <div class="clear"></div>
 </div> 				
<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/diplomas/diploma1.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                          <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
                    </ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>

                        <div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/diplomas/diploma2.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                          <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
                    </ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>

                        <div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/diplomas/diploma3.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                          <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
                    </ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>


                        <div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/diplomas/diploma4.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                          <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
                    </ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>

                        <div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/diplomas/diploma5.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                          <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
                                          </ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                       
                        </div>
             	</div> 				
