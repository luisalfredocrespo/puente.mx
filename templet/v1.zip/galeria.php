<div id="main"><!-- Main -->
        	<div class="hr-invisible-small"></div>
        	<section class="fullwidth-background">
        		<div class="breadcrumb-wrapper">
                    
                </div>                
            </section>
            <div class="hr-invisible-very-small"></div>
            <div class="clear"></div>
            <section id="primary" class="content-full-width"><!-- Primary Section -->
            	<div class="fullwidth-section">
                    <h2 class="border-title aligncenter jmy_web_div" data-page="galeria" id="hola92"data-editor="no">
<?php $this->pnt('hola92','galeria '); ?>
</h2>
                    <div class="hr-invisible-very-small"></div>
                    <div class="container">
                        <div class="dt-sc-sorting-container">
                            <a data-filter=".all-sorte" class="btn-eff3 jmy_web_div" data-page="galeria" id="hola96"data-editor="no">
<?php $this->pnt('hola96','corte de dama '); ?>
</a>     
	<a data-filter=".all-sortes" class="btn-eff3 jmy_web_div" data-page="galeria" id="hola95"data-editor="no"><?php $this->pnt('hola95','corte de caballero'); ?>
</a>     
                            <a data-filter=".cutting" class="btn-eff3 jmy_web_div" data-page="galeria" id="hola94"data-editor="no">
<?php $this->pnt('hola94','Rayos '); ?>
</a>
							  <a data-filter=".all-sort" class="btn-eff3 jmy_web_div" data-page="galeria" id="hola93"data-editor="no">
<?php $this->pnt('hola93','uñas'); ?>
</a>   
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="dt-sc-portfolio-container isotope no-space"> <!-- **dt-sc-portfolio-container Starts Here** -->
					<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte1.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte2.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte3.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                <div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte4.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte5.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte6.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte7.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte8.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte9.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte10.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte11.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte12.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sorte">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/corte13.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero1.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero2.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero3.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                <div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero4.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero5.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero6.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero7.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
								<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero8.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                                
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero9.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero10.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero11.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero12.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero13.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero14.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero15.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero16.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero17.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero18.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero19.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero20.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero21.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero22.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero23.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero24.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero25.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero26.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero27.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sortes">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/caballero28.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas1.jpg" alt="portfolio1" title="">
								
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas2.jpg" ></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas2.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" ></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas3.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" ></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas4.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg"></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas5.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas6.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas7.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></i></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas8.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas9.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas10.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas11.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space all-sort ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/uñas12.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img2.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos1.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						 <div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos2.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos3.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos4.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos5.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos6.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos7.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos8.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul >
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos9.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos10.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos11.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos12.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos13.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos14.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos15.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos16.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos17.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos18.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos19.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						<div class="portfolio dt-sc-one-fourth column no-space  cutting ">
                            <figure>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/rayos20.jpg" alt="portfolio2" title="">
                                <figcaption>
                                    <div class="fig-content">
                                        <ul>
                                        	<li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/portfolio-images/portfolio-img3.jpg" data-gal="prettyPhoto[gallery]" class="button wpshop-cart-button add_to_cart_button product_type_simple"></i></a></li>
                                            <li><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>portfolio-details.html" ></a></li>
										</ul>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
						
                                
                                             
                    </div> <!-- **dt-sc-portfolio-container Ends Here** -->      
                </div>
				<div class="clear"></div>
                <div class="hr-invisible"></div>
                <div class="fullwidth-section dt-sc-parallax-section appointment-parallax dark-bg" style="background-position: 20% 3px;">
                    <div class="fullwidth-bg">
                    	<div class="parallax-spacing">
                    		<div class="container">
                            	<h3 class="border-title jmy_web_div" data-page="galeria" id="hola97">
<?php $this->pnt('hola97','Reserva tu cita con anticipación'); ?>
</h3>
                                <div class="aligncenter">
                                	<a href="<?php echo RUTA_ACTUAL; ?>contacto" class="appointment-btn btn-eff2 jmy_web_div" data-page="galeria" id="hola98">
<?php $this->pnt('hola98','Reserva tu cita '); ?>
</a>
                              	</div>
                            </div>
                        </div>
                   	</div>
             	</div> 
                <div class="clear"></div>
                
                <div class="clear"></div>
                <div class="hr-invisible"></div>
              
                <div class="clear"></div>                 
                <div class="hr-invisible"></div>
            </section><!-- End of Primary Section -->   
        </div><!-- End of Main -->