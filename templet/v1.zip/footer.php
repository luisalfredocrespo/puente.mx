    <footer id="footer">
        <div class="hr-invisible"></div>
            <div class="footer-widgets-wrapper">
                <div class="container">
                	<div class="column dt-sc-one-fourth first">
                    	<aside class="widget widget_text">
                    		<h4 class="widgettitle"> ubicación </h4>
                            <div class="dt-sc-contact-info address">
                            	<p>Calle 4 #87<br>Entre las calles 13 & 15 <br>Col.Espartaco
								<br> 
								Del.Coyoacan</p>
                            </div>
                            <div class="hr-invisible-very-very-small"></div>
                            <h4 class="widgettitle"> Telefono  </h4>
                            <div class="dt-sc-contact-info">
                            	<p class="fa fa-phone-square"> (55)56844906 </p>
                                <p class="fa fa-whatsapp"> (044)5513004391 </p>
                            </div>
                                 <div class="hr-invisible-very-very-small"></div>
                            <h4 class="widgettitle"> Mandanos  Email </h4>
                            <div class="dt-sc-contact-info">
                            	<a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>mailto:yourname@somemail.com" class="dt-sc-clr"> Saloncapri_1315@hotmail.com</a>
                            </div>
                        </aside>
                    </div>
					
                    <div  class="column dt-sc-one-fourth">
                    	<h4 class="widgettitle"> aceptamos tarjetas</h4>
                            <ul class="footer-icons">
                            	<li><a href="<?php echo RUTA_ACTUAL; ?>#" class="fa fa-credit-card"></a></li>     
                            </ul>
							<h4 class="widgettitle"> visa </h4>
							<h4 class="widgettitle"> mastercard  </h4>
							<a title="TrendSal&oacuten" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>index.html"><img title="Sal&oacuten evolution" alt="Sal&oacuten evolution" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/tarjetas-de-credito1.fw.png"></a>
                        </aside>
                 	</div>     
                     

					<div  class="column dt-sc-one-fourth">
                    	<aside class="widget widget_newsletter">
                    		<a title="TrendSal&oacuten" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>index.html"><img title="Sal&oacuten evolution" alt="Sal&oacuten evolution" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/Salon_EVOLUTIOON.fw.png"></a>
                        </aside>
                 	</div>  

					
					
                     <div class="column dt-sc-one-fourth">
                    	<aside class="widget widget_newsletter">
                    		<h4 class="widgettitle"> Correo </h4>
                            <form class="subscribe-frm" method="post" name="frmnewsletter" action="php/subscribe.php">
                                <input type="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>email" placeholder="Saloncapri_1315@hotmail.com" required value="" name="mc_email" >
                                <input class="dt-sc-button small" type="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>submit" value="" name="submit">
                            </form>
                            <div id="ajax_subscribe_msg"></div>
                            <div class="hr-invisible-very-very-small"></div>
                            <h4 class="widgettitle"> siguenos</h4>
                            <ul class="footer-icons">
                            	<li><a href="<?php echo RUTA_ACTUAL; ?>#" class="fa fa-facebook"></a></li>
                                <li><a href="<?php echo RUTA_ACTUAL; ?>#" class="fa fa-instagram"></a></li>
                                <li><a href="<?php echo RUTA_ACTUAL; ?>#" class="fa fa-youtube"></a></li>
                                <li><a href="<?php echo RUTA_ACTUAL; ?>#" class="fa fa-whatsapp"></a></li>
                            </ul>
                        </aside>
                 	</div> 
                </div>
                <div class="hr-invisible-medium"></div>
            </div>
            <div class="copyright">
            	<div class="container">
	            	<p>Copyright © 2000 Sal&oacuten evolution todos los derechos reservados | Página creada por  <a href="https://comsis.mx/e/">Comsis </p>
                </div>
            </div>
       	</footer>         
    </div><!-- End of Inner-Wrapper -->
</div><!-- End of Wrapper -->
  
<!-- **jQuery** -->    
<script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
<script src="<?php $this->url_templet(); ?>js/jquery.parallax-1.1.3.js" type="text/javascript"></script>  
<script type="text/javascript" src="<?php $this->url_templet(); ?>js/jquery.sticky.min.js"></script>         
<script src="<?php $this->url_templet(); ?>js/jquery.inview.js" type="text/javascript"></script>
<script src="<?php $this->url_templet(); ?>js/jsplugins.js" type="text/javascript"></script>
<script src="<?php $this->url_templet(); ?>js/jquery.meanmenu.min.js" type="text/javascript"></script>
<script src="<?php $this->url_templet(); ?>js/custom.js"></script>
<script src="https://maps.google.com/maps/api/js?sensor=false"></script>
<script src="<?php $this->url_templet(); ?>js/jquery.gmap.min.js"></script>

<?php  $this->llamar_js(); ?> 

</body>
</html>