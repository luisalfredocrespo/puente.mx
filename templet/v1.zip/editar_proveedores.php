<div class="row">
    <div class="col-md-4 col-offset-md-3" id="alerta">

    </div>
</div>
<div class="row">
    <div class="col-md-3 col-offset-md-3">
        <input type="hidden" id="ide" value="<?php echo $data['id']; ?>" >
        <input type="text" id="nombre" placeholder="Nombre" value="<?php echo $data['datos']['nombre']; ?>" >
        <input type="text" id="marca" placeholder="marca" value="<?php echo $data['datos']['marca']; ?>" >
        <input type="text" id="direccion" placeholder="direccion" value="<?php echo $data['datos']['direccion']; ?>" >
        <input type="text" id="telefono" placeholder="telefono" value="<?php echo $data['datos']['telefono']; ?>" > <button id="actualizar">Actualizar</button>
     
    </div><div class="col-md-4 col-offset-md-3" ></div> 
</div>
