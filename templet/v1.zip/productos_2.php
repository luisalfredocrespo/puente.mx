
<div class="hr-invisible-small"></div>
                    <h4 class="border-title alignleft sub-title">  </h4>
                    <div class="clear"></div>
                    <div class="hr-invisible-small"></div>
					<div class="clear"></div>
                <div class="hr-invisible"></div>
                <div class="fullwidth-section dt-sc-parallax-section appointment-parallax dark-bg" style="background-position: 20% 3px;">
                    <div class="fullwidth-bg">
                    	<div class="parallax-spacing">
                    		<div class="container">
                            	<h3 class="border-title jmy_web_div" data-page="productos_2" id="hola116">
<?php $this->pnt('hola116','Reserva tu cita con anticipación '); ?>
</h3>
                                <div class="aligncenter">
                                	<a href="<?php echo RUTA_ACTUAL; ?>contacto" class="appointment-btn btn-eff2 jmy_web_div" data-page="contactos_2" id="hola117">
<?php $this->pnt('hola117','Reserva tu cita '); ?>
</a>
                              	</div>
                            </div>
                        </div>
                   	</div>
             	</div> 
					
                    <ul class="dt-sc-tabs-frame dt-sc-ico-content type3">	
                        <li>
                           <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/iconoalfaparf.fw.png" alt="" title="">
							<br> 
							<br> 
							<br> 
                            <h5></h5>
                        </li>
                        <li>
                            <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/iconolenda.fw.png" alt="" title="">
							<br> 
							<br> 
							<br> 
                            <h5> </h5>
                        </li>
                        <li>
                            <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/iconosalerm.fw.png" alt="" title="">
							<br> 
							<br> 
							<br> 
                            <h5> </h5>
                        </li>
						
                        <li>
                            <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/iconotecitaly.fw.png" alt="" title="">
							<br> 
							<br> 
							<br> 
                            <h5> </h5>
                        </li>
                    </ul>
                    <div class="hr-invisible-medium"></div>                           
                    <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                    	<?php  /** apertura descripcion de productos alfaparf**/ ?>
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                             <h6 class="jmy_web_div" data-page="productos_2" id="hola184">
<?php $this->pnt('hola184',''); ?>
                                 illuminating essential oil
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/ampolleta.jpg" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola185">
<?php $this->pnt('hola185',''); ?> 
                                 illuminating essential oil
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola118">
<?php $this->pnt('hola118','tratamiento intensivo amplificador de la luz reduce las asperezas superficiales de fibre capilar y cierra as cuticulas '); ?>
</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">  
                            <h6 class="jmy_web_div" data-page="productos_2" id="hola186">
<?php $this->pnt('hola186',''); ?> illuminating shine lotioon  
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/morada.jpg" alt="" title="">
                                    
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola187">
<?php $this->pnt('hola187',''); ?> illuminating shine lotioon  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola119">
<?php $this->pnt('hola119',''); ?>
tratamiento intensivo revitalizador y perfeccionador, aporta elasticidad y devuelve a los cabellos su brillo natural.
							 </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">  
                            <h6 class="jmy_web_div" data-page="productos_2" id="hola188">
<?php $this->pnt('hola188',''); ?>
                                 illuminating shampoo 
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/product-img1.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola189">
<?php $this->pnt('hola189',''); ?> 
                                 illuminating shampoo  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola120">
<?php $this->pnt('hola120',''); ?>
							una ligera caricia de luz para los cabellos. Fibra capilar suave y revitaliza que resplende al instante, con un efecto duradero.
								</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon"> 
                            <h6> ILLUMUNATING MASK  </h6>
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/product-img2.png" alt="" title=""> 
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola190">
<?php $this->pnt('hola190',''); ?>
                                  ILLUMUNATING MASK  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola121">
<?php $this->pnt('hola121',''); ?>Revitaliza intensamente la fribra capilar para unos cabellos suaves y fluidos, que difunden una luminosidad intensa y vibrante.
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > EXTRAORDINARY ALL-IN-1 FLUID </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/product-img3.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola191">
<?php $this->pnt('hola191',''); ?>
                                 EXTRAORDINARY ALL-IN-1 FLUID 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola122">
<?php $this->pnt('hola122',''); ?>Protege el color cosmético, desenreda los cabellos, protege contra los rayos UVA y UVB, previne la formación de puntas abiertas, controla el peinado, combate el efecto de la humedad, sella las cutículas.
						</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > CRISTALLI LIQUIDI </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/product-img4.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola192">
<?php $this->pnt('hola192',''); ?> 
                                 CRISTALLI LIQUIDI 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola123">
<?php $this->pnt('hola123',''); ?> Tale detraxit accusata et mel, ex nobis fabulas vituperata est mel quodsi labitur graecis eu. Curabitur sed purus fringilla laoreet. Donec fermentum eget nisl non porta. In consequat commodo lorem eu posuere.</p>
                        </div>
                    </div>
					
                    	
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">   
                                <h6>
                                <a target="_blank" > NUTRITIVE SHAMPOO</a>
                            </h6>
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/nutrive shampoo.jpg" alt="" title="">
                                            
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola193">
<?php $this->pnt('hola193',''); ?>
                                 NUTRITIVE SHAMPOO
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola124">
<?php $this->pnt('hola124',''); ?>Limpieza y nutricion sinb apelmezar, para una suavidad y una sedosidad caracteristica de los cabello sanos.
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                             <h6>
                                <a target="_blank" > NUTRITIVE MASK  </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/nutrivemask.jpg" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola194">
<?php $this->pnt('hola194',''); ?>
                                NUTRITIVE MASK  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola125">
<?php $this->pnt('hola125',''); ?> Mejora al instante la calidad de los cabellos, que se vuelven más suaves y facial de desenredar, superando la prueba del peine.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" >NUTRITIVE LEAVE-IN CONDITIONER   </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/nutritive leave in conditioner.JPG" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola195">
<?php $this->pnt('hola195',''); ?> NUTRITIVE LEAVE-IN CONDITIONER </h4>
                            
                            <p class="jmy_web_div" data-page="productos_2" id="hola126">
<?php $this->pnt('hola126',''); ?>
							Siaviza con delicadeza la fibre capilar y aumenta la fkexibilidad de los cabellos.
                            SIN ENJUAGUE.
								</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">  
                             <h6>
                                <a target="_blank"> NUTRITIVE ESSENTIAL OIL  </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/NUTRITIVE ESSENTIAL OIL.JPG" alt="" title=""> 
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola196">
<?php $this->pnt('hola196',''); ?>NUTRITIVE ESSENTIAL OIL 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola127">
<?php $this->pnt('hola127',''); ?> Revitaliza intensamente la fribra capilar para unos cabellos suaves y fluidos, que difunden una luminosidad intensa y vibrante.
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > SPLIT ENDS RECOVERY FLUID </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/SPLIT ENDS RECOVERY FLUID.jpg" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola197">
<?php $this->pnt('hola197',''); ?>
                                 SPLIT ENDS RECOVERY FLUID 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola128">
<?php $this->pnt('hola128',''); ?> producto específico para la zona más frágil de los cabellos secos: las puntas. Sella las puntas secas y desfibradas, formando un velo invisible que las envuelve, reforzándolas y enriquece la fibra capilar, evitando que se rompa.
							SIN ENJUAGUE
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > REPARATIVE SHAMPOO </a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/REPARATIVE SHAMPOO.jpg" alt="" title="">
                                            
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola198">
<?php $this->pnt('hola198',''); ?>
                                 REPARATIVE SHAMPOO 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola129">
<?php $this->pnt('hola129',''); ?> Actúa sobre el corazón de la fibra, cubriendo las carencias de los elementos que le faltan </p>
                        </div>
                    </div>
					
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > REPARATIVE MASK </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/REPARATIVE mask.fw.png" alt="" title="">
                                            
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola199">
<?php $this->pnt('hola199',''); ?>
                                 REPARATIVE MASK 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola130">
<?php $this->pnt('hola130',''); ?> Consolida, refuerza y reestructura la corteza, aumentando la resistencia a la rotura. 
							Los cabellos desfribrados se reconsituyen y adquieren de nuevo gradualmente su belleza natural.
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank"> DAILY ANTI-BREAKAGE FLUID  </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/DAILY ANTI-BREAKAGE FLUID.fw.png" alt="" title="">
                                            
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola200">
<?php $this->pnt('hola200',''); ?> 
                                 DAILY ANTI-BREAKAGE FLUID 
                            </h4>
                            <p  class="jmy_web_div" data-page="productos_2" id="hola131">
<?php $this->pnt('hola131',''); ?> Sigue diariamente con el proceso de reparación, sellando las cutículas y creando una barrera de protección antirrotura. 
							Los cabellos se rellenan sin perder fluidez ni suavidad.
							
                            Sin enjuague  
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > REPARATIVE LOTION  </a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/REPARATIVE LOTION.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola201">
<?php $this->pnt('hola201',''); ?>
                                 REPARATIVE LOTION  
                            </h4>
                            <p
							class="jmy_web_div" data-page="productos_2" id="hola132">
<?php $this->pnt('hola132',''); ?> tratamiento de reestructuración instantánea de los daños de la fibra capilar desfibrada y frágil.
							usando diariamente, los cabellos recobran su vigor natural.
							 sin enjuagar

													
								
								</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon"> 
                             <h6>
                                <a target="_blank" >  frizz control shampoo </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/frizz control shampoo.fw.png" alt="" title=""> 
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola202">
<?php $this->pnt('hola202',''); ?>frizz control shampoo 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola133">
<?php $this->pnt('hola133',''); ?>Controla y suaviza los cabellos sin apelmazarlos haciéndolos más fáciles  de mantener y más luminosos 
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > FRIZZ CONTROL BUTTER MASK</a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/FRIZZ CONTROL BUTTER MASK.fw.png" alt="" title="">
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola203">
<?php $this->pnt('hola203',''); ?>
                                FRIZZ CONTROL BUTTER MASK
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola134">
<?php $this->pnt('hola134',''); ?>Tratamiento antiaspereza, garantiza suavidad, control y luminosidadintensa.
							</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > ENERGIZING LOTION   </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/ENERGIZING LOTION.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola204">
<?php $this->pnt('hola204',''); ?>
                                ENERGIZING LOTION   
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola135">
<?php $this->pnt('hola135',''); ?> Concentrado energizante intensivo la fibra capilar, haciéndola mas fuerte y resistente con efecto hot-ice</p>
                        </div>
                    </div>
					
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > PURIFY SHAMPOO</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/PURIFY SHAMPOO.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola205">
<?php $this->pnt('hola205',''); ?> 
                                 PURIFY SHAMPOO
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola136">
<?php $this->pnt('hola136',''); ?>Elimina la caspa desde la primera aplicación y retrasa su aplicación. De alivio, reduce picor y ayuda al cuero cabelludo  a readquirir el equilibrio adecuado dejando el cabello luminoso.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > ILLUMINATING HAIRSPRAY</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/ILLUMINATING HAIRSPRAY.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola206">
<?php $this->pnt('hola206',''); ?>
                                ILLUMINATING HAIRSPRAY  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola137">
<?php $this->pnt('hola137',''); ?> El ultimo toque para tener los reflectores apuntados sobre nuestro peinado.
							Sigue el movimiento de los cabellos sin apelmazrlos. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon"> 
                             <h6>
                                <a target="_blank" > ILLUMINATING EXTRA STRONG HAIRSPRAY </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/ILLUMINATING EXTRA STRONG HAIRSPRAY.fw.png" alt="" title="">
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola207">
<?php $this->pnt('hola207',''); ?>
                                 ILLUMINATING EXTRA STRONG HAIRSPRAY 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola138">
<?php $this->pnt('hola138',''); ?>
							Un toque de luz absoluto de larga duración para unos resultados más estructurados.
                            Fijador extremo que dura todo el día, eliminándose con algunos simples cepillados
								</p>
                        </div>
                    </div>
                    
					
						<?php  /** cierre descripcion de productos alfaparf**/ ?>
                    </div>
                    <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                    	<?php  /** apertura descripcion de productos LENDA**/ ?>
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > oil essences</a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/oil essences.fw.png" alt="" title="">
                                       
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola208">
<?php $this->pnt('hola208',''); ?> oil essences
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola139">
<?php $this->pnt('hola139',''); ?> OIL ESSENCES te aportará brillo, vigor, hidratación y protección, a la vez que combaten el encrespamiento y los síntomas de la edad de tu cabello. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/oil essences ethernal moringa.png" alt="" title="">
                                        
                            </div>
                            <h4>
                                <a target="_blank" > </a>
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola140">
<?php $this->pnt('hola140',''); ?> En cierto modo se rejuvenece el cabello desde su interior. Además, estos mismos minerales y vitaminas hacen que el cabello sea más fuerte y lucha contra la caspa y las puntas abiertas.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" > OIL ESSENCES 10ML </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/OIL ESSENCES 10ML..fw.png" alt="" title="">       
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola209">
<?php $this->pnt('hola209',''); ?>
                               OIL ESSENCES 10ML
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola141">
<?php $this->pnt('hola141',''); ?> 
							Concentrado del aceite Essences para una recuperación del brillo y la vitalidad del cabello de una forma intensa y rápida.
							</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">
                            <h6>
                                <a target="_blank" >  OIL ESSENCES ETHER 10ML </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/OIL ESSENCES ETHERNAL 10ML..fw.png" alt="" title=""> 
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola210">
<?php $this->pnt('hola210',''); ?> 
                                 OIL ESSENCES ETHER 10ML 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola142">
<?php $this->pnt('hola142',''); ?> Aplica una pequeña cantidad de Oil Essences Ethernal Moringa en la palma de la mano y distribuye sobre el cabello, una vez lavado. Peinar como de costumbre </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > hair cream 360 </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/hair cream 360.fw.png" alt="" title="">
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola211">
<?php $this->pnt('hola211',''); ?>
                                hair cream 360 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola143">
<?php $this->pnt('hola143',''); ?> proporciona mas de diez beneficios en un solo producto .Este sistema sin enjuagado es un efectivo reparador de la fibra capilar que aporta beneficios visibles para el cabello desde la primera aplicacion. </p>
                        </div>
                    </div>
                   
				
						<?php  /** cierre descripcion de productos LENDA**/ ?>
                    </div>
                    <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                    	 <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                    	<?php  /** apertura descripcion de productos salerm**/ ?>
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > straightening spray</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/straightening spray.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola212">
<?php $this->pnt('hola212',''); ?> 
                                 straightening spray
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola144">
<?php $this->pnt('hola144',''); ?> Proteinas Hidrolizadas que facilita el planchado del cabello. Crea una barrera de protección de la fibra caílar frente al calor.Fortifica e hidrata el cabello para alisar la superficie capilar de la raíz a la punta.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                             <h6>
                                <a target="_blank" > volume dust 01  </a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/volumedust01.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola213">
<?php $this->pnt('hola213',''); ?> 
                                volume dust 01  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola183">
<?php $this->pnt('hola183',''); ?> Polvo de peinado volumen y densidad </p>
                                
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" >matt clay 02 </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/mattclay02.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola214">
<?php $this->pnt('hola214',''); ?> matt clay 02 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola145">
<?php $this->pnt('hola145',''); ?> 
							Arcilla diseñada para painar y crear looks con efecto mate.Ideal para cabellos medios y medios largos.Fijacion flexible de larga duración.Además aporta hidratación y acondicionamiento.						
								</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" >  liss foam 01  </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/lissfoam01.fw.png" alt="" title=""> 
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola215">
<?php $this->pnt('hola215',''); ?>  liss foam 01 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola146">
<?php $this->pnt('hola146',''); ?> Elimina el encrespamiento, facilitando y mejorando el resultado del alisado con plancha p secador, al tiempo que trata y repara en profundidad el cabello gracias al complejo de querartina kera-3 System.Tecnologia activada por calor y termo-proctectora.larga duracion sin residuos.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank">tratamiento hi repair </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tratamientohirepair.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola216">
<?php $this->pnt('hola216',''); ?>  
                                tratamiento hi repair 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola147">
<?php $this->pnt('hola147',''); ?> Tratamiento rejuvenecedor para el cabello en 3 pasos.
							Resultados inmediatos y espectaculares: cabellos sanos, fuertes y con cuerpo.</p>
							<br>
								<br>
								<br>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > balsam with protein  </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/balsamwithprotein.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola217">
<?php $this->pnt('hola217',''); ?>  balsam with protein  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola148">
<?php $this->pnt('hola148',''); ?> Devuelve el equilibrio natural al cabello castigado,tanto por los efectos ambientales como por los procesos técnicos con este bálsamo rico en activos acondicionadores. El cabello recuperará inmediatamente la suavidad,luminosidad y brillo. Es ideal para todo tipo de cabellos</p>
                        </div>
                    </div>
					
                    	
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > protein </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/protein.fw.png" alt="" title="">
                                     
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola218">
<?php $this->pnt('hola218',''); ?>  
                                 protein 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola149">
<?php $this->pnt('hola149',''); ?> Champú Proteínas Línea Oro es un champú especialmente indicado tras trabajos técnicos para aportar un extra de proteínas al cabello. Su fórmula combinada con una base para el lavado suave y delicada, con un hidrolizado de proteínas que actúa sobre el cabello, proporciona un resultado con protección, brillo, manejabilidad y cuerpo.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > white blanco   </a>
                            </h6>  
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/whiteblanco.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola219">
<?php $this->pnt('hola219',''); ?>  
                                 white blanco   
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola150">
<?php $this->pnt('hola150',''); ?> es un champú especialmente indicado para cabellos canosos ya que elimina los tonos amarillos, devolviendo el brillo y la luminosidad del cabello bien cuidado. Su fórmula incorpora una combinación de colorantes semipermanentes con una tonalidad violeta que garantiza la eliminación progresiva de la tonalidad amarillenta de los cabellos canosos.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                             <h6>
                                <a target="_blank" > mascarilla germen de trigo</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/mascarillagermendetrigo.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola220">
<?php $this->pnt('hola220',''); ?>  
                                 mascarilla germen de trigo
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola151">
<?php $this->pnt('hola151',''); ?> 
							Mascarilla hidratante intensiva de efecto  progresivo, especial para recuperar cabellos deshidratados y castigados.
								
								</p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > aceite esencial acondicionador  </a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/aceiteesencialacondicionador.fw.png" alt="" title=""> 
                                       
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola221">
<?php $this->pnt('hola221',''); ?>   
                                aceite esencial acondicionador  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola152">
<?php $this->pnt('hola152',''); ?> es un tratamiento en ampolleta ideal para cabellos secos, tratados y/o tinturados. Su fórmula con proteínas de seda proporciona una acción profunda de hidratación interna, recuperando la humedad del cabello.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon">
                            <h6>
                                <a target="_blank" > mega acondicionadora</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/megaacondicionadorar.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola222">
<?php $this->pnt('hola222',''); ?>   
                                 mega acondicionadora
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola153">
<?php $this->pnt('hola153',''); ?> Ampolleta reestructurante de hidratación capilar profunda para cabellos maltratados y secos. Con acción termo activa.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon"> 
                             <h6>
                                <a target="_blank" >kera-plus </a>
                            </h6> 
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/kera-plus.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola223">
<?php $this->pnt('hola223',''); ?>   kera-plus 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola154">
<?php $this->pnt('hola154',''); ?> Ampolleta de uso frecuente para el alisado.Su alto contenido en keratina deja el cabello más manejable y con más brillo.</p>
                        </div>
                    </div>
					
						<div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">
                             <h6>
                                <a target="_blank" > grapeology</a>
                            </h6>   
                            	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/grapeology.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola224">
<?php $this->pnt('hola224',''); ?>   
                             grapeology
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola155">
<?php $this->pnt('hola155',''); ?> El aceite a base de pepita de uva nutre e hidrata en profundidad es rico en antioxidantes, mejora el brillo del cabello y previene los daños de los agentes externos.Actúa como reparador capilar y protector de la queratina, previniendo el envejecimiento del cabello </p>
                        </div>
                    </div>
                  
                    
					
						<?php  /** cierre descripcion de productos salerm**/ ?>
                    </div>
                    </div>
                    <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                    	
                       <?php  /** apertura descripcion de productos  tec ytaly**/ ?>
                        <div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#"> olio vital</a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/olio vital.fw.png" alt="" title="">
                                   
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola225">
<?php $this->pnt('hola225',''); ?>  
                                 olio vital
                            </h4>
                            
                                <p class="jmy_web_div" data-page="productos_2" id="hola156">
<?php $this->pnt('hola156',''); ?> 
                            tratamiento concentrado revitalizante para cabello y piel 
                               creado un concentrado exclusivo de  aceites asenciales, extraídos de platas ricas en ácidos ,vitaminas y antioxidantes, los cuales ayudan a proteger y restituir naturalmente las propiedades del cabello y piel , aportando la fuerza y vitalidad perdida, manteniendo su belleza natural, con una textura ligera y sedosa.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> shampoo post color </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/postcolor.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola225">
<?php $this->pnt('hola225',''); ?>   
                                 shampoo post color 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola157">
<?php $this->pnt('hola157',''); ?> shampoo ideal para cabello teñido.Ayuda a prevenir la pérdida prematura del color sellado la cutícula con un ph de 4,5 ayudando a mantener por más tiempo un color brillante. Protegiendo el color de los rayos U.V. Su fórmula agrega suavidsad y sedosidad al cabello. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">  due faccetta lunga durata  </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy due faccetta lunga durata.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola226">
<?php $this->pnt('hola226',''); ?>   
                                due faccetta lunga durata  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola158">
<?php $this->pnt('hola158',''); ?> 
                            Tratamiento nutritivo instantáneo diseñado para proteger y fijar el color.Se deja puesto.Formulado para sellar la cutícula optimizando el brillo y evitando la pérdida prematura del color en el cabello.                         
                               
                                </p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">  shampoo balsami presto </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/shampoo balsami presto tec italy.fw.png" alt="" title=""> 
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola227">
<?php $this->pnt('hola227',''); ?>   
                                  shampoo balsami presto 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola159">
<?php $this->pnt('hola159',''); ?> Shampoo para cabellos frágiles, dañados por agreciones ambientales, tratamientos químicos, procesos de estilizado, contaminación y elpaso del tiempo.Restaura la fortaleza y vitalidad del cabello desde su interior, eliminando el riesgo de cabelloo quebradizo, previniendo las puntas abiertas y facilitando el desenredo.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">  balsami presto </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/balsami presto tec italy.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola228">
<?php $this->pnt('hola228',''); ?>   
                                  balsami presto 
                            </h4>
                             <p class="jmy_web_div" data-page="productos_2" id="hola160">
<?php $this->pnt('hola160',''); ?> Tratamiento revitalizante intensivo que se deja puesto. Proporciona desenredo, volumen y humectación. Ideal para cabellos químicamnete procesados. Bálsamo protector de la hebra capilar. Combina elementos proteínicos y botánicos. Además protege el cabello de los dañinos efectos del sol y del mendio ambiente. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon">  
                            <h6>
                                <a target="_blank" href="#">lumina shampoo </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy lumina shampoo.fw.png" alt="" title="">
                                      
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola229">
<?php $this->pnt('hola229',''); ?>   
                                lumina shampoo 
                            </h4>
                           <p class="jmy_web_div" data-page="productos_2" id="hola161">
<?php $this->pnt('hola161',''); ?> Formulado en tono azul-violeta. Matiza y ayuda a reavivar el tono del cabello decolorado o naturalmente rubio, cuando éste ha adquirido cierto reflrejo verdoso, cobrizo u opaco. Matiza las canas, neutralizando los tonos amarillentos. Suaviza, abrillanta y ayuda a fortalecer a tu cabello, ya que está enriquecido por complejos proteínicos y botánicos. </p>
                        
                        </div>
                    </div>
                    
                        
                        <div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#"> lumina conditioner</a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy lumina conditioner.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola230">
<?php $this->pnt('hola230',''); ?>   
                                 lumina conditioner
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola162">
<?php $this->pnt('hola162',''); ?> Acondicionador matizador para cabello rubio ó blanco. Complemento ideal de LIMINA SHAMPOO. Matiza y reaviva el tono del cabello decolorado o naturalmete rubio, cuando éste ha adquirido  cierto reflejo verdoso, cobrizo u opaco. Matiza las canas y da brillo , neutralizando los tonos amarillentos. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">lumina forza colore  </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy lumina forza colore.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola2301">
<?php $this->pnt('hola231',''); ?>  lumina forza colore  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola163">
<?php $this->pnt('hola163',''); ?> Tratamiento revitalizante e intensidificador de color para el cabello. Prolonga la duracion del color en cabello teñido durante más tiempo. Ideal para cabellos maltratados y resecos. Sus finos ingredintes  depositan acondicionadores y pigmentos en tu cabello, otorgándo brillo, sedosidad y manejabilidad.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon"> 
                                <h6>
                                <a target="_blank" href="#"> silk system shine</a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy silk system shine.fw.png" alt="" title="">
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola232">
<?php $this->pnt('hola232',''); ?>   
                                silk system shine
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola164">
<?php $this->pnt('hola164',''); ?> Innovador tratamiento que proporcona extraordinario brillo instantáneo. Ayuda a revitalizar las puntas y la cutícula del cabello, además de protegerlo de los rayos del sol .Gracias a su pontente filtro UV es el toque final perfecto para el proceso de estilizado, ya que contiene proteína de seda que otorga gran brillo, desenredo y reacondicionamiento. 
                                </p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#">Shampoo Massimo </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/tec italy shampoo massimo.fw.png" alt="" title=""> 
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola233">
<?php $this->pnt('hola233',''); ?>   
                                Shampoo Massimo 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola165">
<?php $this->pnt('hola165',''); ?> Fórmula cristalina de recostrucción intensiva para el cabello. Brinda limpieza, acondicionamiento y humectación. Repara y estabiliza los aceites esenciales naturales del cabello, otorgándole brillo y suavidad. Ideal para cabellos dañados o químicamente procesados. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon"> <h6>SHAMPOO TOTALE</h6>

                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/shampoo totale tec italy.fw.png" alt="" title="">
                                     
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola234">
<?php $this->pnt('hola234',''); ?>    SHAMPOO TOTALE 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola166">
<?php $this->pnt('hola166',''); ?> Shampoo acondicionador para cabello seco y maltratado. Diseñado para ayudar a limpiary reacondicionar  simultáneamente el cabello, especialmente los maltratados por procesos químicos. Aporta a tu cabello, ya que está enriquecido por complejos proteínicos y botanícos. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> Balsami Totale</a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Blsami totale tec italy.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola234">
<?php $this->pnt('hola234',''); ?>  
                                Balsami Totale
                            </h4>
                            
                            <p class="jmy_web_div" data-page="productos_2" id="hola167">
<?php $this->pnt('hola167',''); ?> Tratamiento acondicionador reconstructor nutritivo instantáneo que repara el cabello dañado, brindando brillo,sedosidad y desenredo.</p>
                        </div>
                    </div>
                    
                        <div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon">
                                <h6>
                                <a target="_blank" href="#"> Due Faccetta Massimo</a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/due faccetta massimo tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola235">
<?php $this->pnt('hola235',''); ?>   
                                Due Faccetta Massimo
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola168">
<?php $this->pnt('hola168',''); ?> Tratamiento nutritivo instantáneo sin enjuague de dos fases para cabellos muy maltratdos por porcesos químicos, elementos ambientales y fuentes externas de calor. Hidrata, acondiciona y regula la porosidad del cabello. Cierra la cutícula y proporciona brillo al cabello.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#"> shampo tonico</a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/shampo tonico  tec italy.fw.png" alt="" title="">         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola236">
<?php $this->pnt('hola236',''); ?>   
                                 shampo tonico
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola169">
<?php $this->pnt('hola169',''); ?> Tratamiento en shampoo para cabellos débiles, delgados y sin volumen. Combina los complejos proteínicos y botánicos que refuerzan y nutren el cabello. Ayuda a detener la caída prematura.Da un balance de lubricación y humedad al cuerpo cabelludo.
                            </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> scultore fine   </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/scultore fine tec italy.fw.png" alt="" title="">
                                        
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola237">
<?php $this->pnt('hola237',''); ?>   
                                scultore fine   
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola170">
<?php $this->pnt('hola170',''); ?> Espectacular gel líquido creado parta trabajar con las manos, que ayuda a marcar y fijar rizos. Otorga cuerpo, textura y brillo al cabello. Contiene pantenol.  
                            
                            </p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">
                                <h6>
                                <a target="_blank" href="#">  Gel della cera effetto normale </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Gel della cera effetto normale tec italy.fw.png" alt="" title=""> 
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola238">
<?php $this->pnt('hola238',''); ?>   
                                  Gel della cera effetto normale 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola171">
<?php $this->pnt('hola171',''); ?> Cera gel para transformarmaciones instantáneas con fijación fuerte, que agiliza el proceso de estilizado dando un aparencia fresca y limpia; es fácil de remover y de larga duración, genera un efecto texturizado natural sin dejar residuos.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon"> 
                                <h6>
                                <a target="_blank" href="#"> Gel della cera effetto humedo </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Gel della cera effetto humedo tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola239">
<?php $this->pnt('hola239',''); ?>   Gel della cera effetto humedo 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola172">
<?php $this->pnt('hola172',''); ?> Cera gel para transformarmaciones instantáneas con fijación fuerte, que agiliza el proceso de estilizado dando un aparencia fresca y limpia; es fácil de remover y dura todo el día  dando un  efecto texturizado húmedo sin dejar residuos.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> Volumi e Corpo Mousse  </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/volumi e corpo mousse tec italy.fw.png" alt="" title="">
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola240">
<?php $this->pnt('hola240',''); ?>    Volumi e Corpo Mousse 
                            </h4>
                            <br>
                            <p class="jmy_web_div" data-page="productos_2" id="hola173">
<?php $this->pnt('hola173',''); ?> El más avanzado mousse creado para aportar extraordinario brillo. cuerpo y control a los peinados. Combina elementos proteínicos y herbales como tricone tricoerba.
                            <br>
                            </p>
                            <br>
                        </div>
                    </div>
                    
                        <div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#"> Gellini gel </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/gellini gel tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola241">
<?php $this->pnt('hola241',''); ?>  
                                 Gellini gel 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola174">
<?php $this->pnt('hola174',''); ?> Gel reactivable y de secado rápido con fijación extrema.Deja el cabello con aspecto mojado. Fórmula enriquecida con tricone y trecil-r.
                            </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> Brillare Trattanti  </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/brillare trattanti tec italy.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola242">
<?php $this->pnt('hola242',''); ?>  
                                 Brillare Trattanti  
                            </h4>
                            
                            <p class="jmy_web_div" data-page="productos_2" id="hola175">
<?php $this->pnt('hola175',''); ?> Poderoso tratamiento concentrado que se deja puesto, da máximo brillo y desenredo.Formulado con los más finos silicones.</p>
                            
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> brillare mist </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/brillare mist tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola243">
<?php $this->pnt('hola243',''); ?>  
                                 brillare mist 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola176">
<?php $this->pnt('hola176',''); ?> 
                            El toque para estilizar su cabello. Brinda súper brillo instantáneo, y es un estraordinario reacondicionante.
                            
                            </p>
                        </div>
                    </div>
                    <div class="dt-sc-tabs-frame-content dt-sc-ico-content">
                        
                      
                        <div class="hr-invisible-small"></div>
                    
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 cog">
                            <div class="icon"> 
                             <h6>
                                <a target="_blank" href="#"> Pazzicera </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/pazzicera tec italy.fw.png" alt="" title="">
                                   
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola244">
<?php $this->pnt('hola244',''); ?>  
                                 Pazzicera 
                            </h4>
                             
                           <p class="jmy_web_div" data-page="productos_2" id="hola177">
<?php $this->pnt('hola177',''); ?>  Versátil cera para definir peinados. Ideal para jóvenes que desean un aspecto urbano/mate en su cabello y para peinados con aspectos con desenfadado. Sin brillo, especial para cabellos cortos y despeinados con una fijación media.</p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 anchor">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> Pasta della aragña </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Pasta della aragña  tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola245">
<?php $this->pnt('hola245',''); ?>  
                                 Pasta della aragña 
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola178">
<?php $this->pnt('hola178',''); ?>  Cera elástica con las más moderna tecnoligía para texturizar. Permite los procesos de treanformación más radicales posibles, creando volumen donde no lo hay. Gracias asu avanzada y exclusiva fórmula, logra gran definicíon en picos y mechones. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 magic">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">  Stravaganza wax  </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Stravaganza wax tec italy.fw.png" alt="" title="">
                                          
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola246">
<?php $this->pnt('hola246',''); ?>  
                                 Stravaganza wax  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola179">
<?php $this->pnt('hola179',''); ?>  
                            Cera de finalizado no grasosa con terminado mate. Crea estilos únicos, con tectura, moldeables y definidos. Gracias a su consistencia cremosa es de fácil distribucíon. Para todo tipo de cabello, ideal para cabellos cortos y estilos degrafilados. Cuenta con dos niveles de fijación: media y fuerte.
                                </p>
                        </div>
                    </div>
                    <div class="hr-invisible-small"></div>
                    <div class="column dt-sc-one-third first">
                        <div class="dt-sc-ico-content type4 desktop">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#">  shampoo profondo  </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/shampoo profondo tec italy.fw.png" alt="" title=""> 
                                           
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola247">
<?php $this->pnt('hola247',''); ?>  
                                 shampoo profondo  
                            </h4>
                            <p class="jmy_web_div" data-page="productos_2" id="hola180">
<?php $this->pnt('hola180',''); ?>  
                        Shampoo de limpieza profunjda para cabello cuero cabellurdo, ayuda a retirar el exceso de grasa, resuido cosméticos, de cloro y minerales.
                             </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 trophy">
                            <div class="icon">
                            <h6>
                                <a target="_blank" href="#"> Duo faccetta  giorno per giorno </a>
                            </h6>   
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/duo facCetTa  giorno per giorno  tec italy.fw.png" alt="" title="">
                                         
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola248">
<?php $this->pnt('hola248',''); ?> 
                                 Duo faccetta  giorno per giorno 
                            </h4>
                             <p class="jmy_web_div" data-page="productos_2" id="hola181">
<?php $this->pnt('hola181',''); ?>  Poderoso tratamiento instantáneo sin enjuague de uso diario desarollado para el cabello normal o seco. HIdrata, mutre y senreda gracias a su concentración de complejo proteínico, complejo orgánico natural y reconstruvtor proteínico único en el mundo, constituido de seda, queratina y trijo , complejo botánico que tiene funciones antisépticas, antiseborreicas y humectantes, compuesto protector capilar que combina los más finos silicones para un cuidado y  acondicionamiento máximos del cabello. </p>
                        </div>
                    </div>
                    <div class="column dt-sc-one-third">
                        <div class="dt-sc-ico-content type4 plane">
                            <div class="icon"> 
                            <h6>
                                <a target="_blank" href="#">Shampoo Bambini </a>
                            </h6>  
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/producto2/Shampoo Bambini  tec italy.fw.png" alt="" title="">
                                      
                            </div>
                            <h4 class="jmy_web_div" data-page="productos_2" id="hola249">
<?php $this->pnt('hola249',''); ?> 
                               Shampoo Bambini 
                            </h4>
                           <p class="jmy_web_div" data-page="productos_2" id="hola182">
<?php $this->pnt('hola182',''); ?>   Diseñado para cuero cabelludo sensible,cabello delgado y fino , como el de niños y bebés. Limpia suavemente sin retirar los aceites naturales esenciales para el cabello. Proporciona brillo, suavidad y humectación. Ideal para uso diario e ó 3 veces al dia. Su formula enriquecida con tricine protege el cabello delicado, fortaleciéndo , generando desenredo, docilidad y brillo. </p>
                        
                        </div>
                    </div>
                    
                    
                    
                        <?php  /** cierre descripcion de productos tec y taly**/ ?>
                    </div>
                    </div>
                    </div>