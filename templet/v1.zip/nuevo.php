<?php 
echo "hola";
?>