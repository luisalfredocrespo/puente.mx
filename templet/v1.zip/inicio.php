        <div id="main"><!-- Main -->
            <div class="banner">
            	<div class="fullwidth-section dt-sc-parallax-section slider-bg">
                	<div class="parallax-spacing">
                    	<div class="container">
                        	<div class="caption">
                            	<h2 class="jmy_web_div" data-page="inicio" id="slider_1" data-editor="no"><?php $this->pnt('slider_1','Money Doesn’t<br>Come   <span class="color-default">Without Care</span>');?></h2>
                                <p></p>
                                
                            </div>
                            <div class="hr-invisible"></div>
                            <div class="hr-invisible"></div>
                            <div class="aligncenter">
                            	<div id="scrolldown">
                                    <a href="<?php echo RUTA_ACTUAL; ?>"><i class="fa fa-angle-double-down  animate" data-animation="fadeInDown animated"></i><br />Desliza hacia abajo</a>
                                </div>
                            </div>
                            <div class="hr-invisible"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" clear"></div>
            <div class="opening-time-info">
            	<div class="container">
                	<ul class="time-info">
                    	<li><i class="fa fa-clock-o"></i><span>Hora de </span> Apertura</li>
                        <li>lunes a  viernes 9:<span>AM A</span> 8:30<span>PM</span></li>
						<li>sadados 9:<span>AM A</span> 7:00<span>PM</span></li>
                    </ul>
                    <div class="alignright">
                    	<a href="<?php echo RUTA_ACTUAL; ?>" class="appointment-btn btn-eff2"><i class="fa fa-pencil-square-o"></i>Reserva <span>tu cita  </span></a>
                    </div>
                </div>
            </div>
            <div class="container"><!-- Container -->
            	<h2 class="border-title aligncenter jmy_web_div" data-page="inicio" id="hola1"data-editor="no" >
                <?php $this->pnt('hola1','Bienvenidos a su Sal&oacuten.'); ?>
                     
                </h2>
                <p class="aligncenter jmy_web_div" data-page="inicio" id="hola" data-editor="no" >
                <?php $this->pnt('hola','El Salón evolution le da la bienvenida este es su Salón de belleza para usted aquí encontrara el cambio de look tanto como para damas y caballeros, queremos que se sienta cómodo y satisfecho gracias por su visita.'); ?></p>
				<div class="clear"></div>
                <div class="hr-invisible-medium"></div>
                <div class="hr-invisible-very-very-small"></div>
                <div class="column dt-sc-one-fourth first">
                	<div class="dt-sc-service type1 animate" data-delay="100" data-animation="fadeIn animated">
                    	<figure class="gallery-thumb">
                        	<a href="<?php echo RUTA_ACTUAL; ?>"><img class="dt-sc-filter" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-img1.jpg" alt="" title=""></a>
                        </figure>
                        <div class="icon">
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="first-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon1.png" alt="" title=""></a>
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="second-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon5.png" alt="" title=""></a>
                        </div>
                        <h3 class="jmy_web_div" data-page="inicio" id="hola2" data-editor="no">
                        <?php $this->pnt('hola2','Cortes'); ?></h3>
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                	<div class="dt-sc-service type1 animate" data-delay="200" data-animation="fadeIn animated">
                    	<figure class="gallery-thumb">
                        	<a href="<?php echo RUTA_ACTUAL; ?>"><img class="dt-sc-filter" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-img2.jpg" alt="" title=""></a>
                        </figure>
                        <div class="icon">
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="first-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon2.png" alt="" title=""></a>
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="second-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon6.png" alt="" title=""></a>
                        </div>
                        <h3 class="jmy_web_div" data-page="inicio" id="hola3" data-editor="no" >
                        <?php $this->pnt('hola3','barbas'); ?></h3>
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                	<div class="dt-sc-service type1 animate" data-delay="300" data-animation="fadeIn animated">
                    	<figure class="gallery-thumb">
                        	<a href="<?php echo RUTA_ACTUAL; ?>"><img class="dt-sc-filter" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-img3.jpg" alt="" title=""></a>
                        </figure>
                        <div class="icon">
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="first-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon3.png" alt="" title=""></a>
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="second-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon7.png" alt="" title=""></a>
                        </div>
                        <h3 class="jmy_web_div" data-page="inicio" id="hola4" data-editor="no">
                        <?php $this->pnt('hola4','Secados y alaciados');?></h3>
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                	<div class="dt-sc-service type1 animate" data-delay="400" data-animation="fadeIn animated">
                    	<figure class="gallery-thumb">
                        	<a href="<?php echo RUTA_ACTUAL; ?>"><img class="dt-sc-filter" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-img4.jpg" alt="" title=""></a>
                        </figure>
                        <div class="icon">
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="first-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon4.png" alt="" title=""></a>
                            <a href="<?php echo RUTA_ACTUAL; ?>"><img class="second-img" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-icon8.png" alt="" title=""></a>
                        </div>
                        <h3 class="jmy_web_div" data-page="inicio" id="hola5" data-editor="no"><?php $this->pnt('hola5','tratamientos');?></h3>
                    </div>
                </div>
            </div><!-- End of Container -->
            <div class="clear"></div>
            <div class="hr-invisible"></div>
            <div class="fullwidth-section dt-sc-parallax-section pricing-parallax dark-bg">
               <?php /*   <div class="fullwidth-bg">
                    <div class="parallax-spacing">
                        <div class="container"><!-- Container -->
                        	<h2 class="border-title aligncenter"> Nuestras ofertas </h2>
                            <div class="hr-invisible-small"></div>
                            <div class="column dt-sc-one-fourth first">
                            	<div class="animate" data-delay="200" data-animation="fadeIn animated">
                                    <h3 class="border-title">Sal&oacuten<span>  Evolution</span></h3>
                                    <p>Aproveche las ofertas .</p>
                                    <div class="dt-sc-offer-text">
                                        <h2>50</h2>
                                        <span>%<span>off</span></span>
                                    </div>
                                    <div class="clear"></div>
                                    <ul class="dt-sc-offer-date">
                                        <li>
                                            <span class="fa fa-calendar"></span>
                                            Martes 24 de octubre 
                                        </li>
                                        <li>
                                            <span class="fa fa-map-marker"></span>
                                            ubicación
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="column dt-sc-three-fourth">
                            	<div class="dt-sc-offer-carousel-wrapper animate" data-delay="400" data-animation="fadeIn animated">
                                	<div class="dt-sc-offer-carousel">
                                    	<div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img1.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">Mechas californianas</a></h4>
                                                    <div class="dt-sc-price">
                                                    	$ 600
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL; ?>" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">corte en capas</a></h4>
                                                    <div class="dt-sc-price">
                                                    	2x1
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL; ?>" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/blog-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">tratamientos</a></h4>
                                                    <div class="dt-sc-price">
                                                    	$ 1200
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#">Hair Coloring</a></h4>
                                                    <div class="dt-sc-price">
                                                    	£ 200
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" data-text="View Details"><span>View Details</span></a>
                                                </div>
                                            </div>
                                        </div>
	                                </div>
                                	<div class="carousel-arrows">
                                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="prev-arrow"><i class="fa fa-angle-left"></i></a>
                                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="next-arrow"><i class="fa fa-angle-right"></i></a>
										
                                    </div>
                                </div>
                            </div>
                            <div class="hr-invisible-small"></div>
                            <div class="hr-invisible-very-small">
							</div>
                        </div><!-- End of Container -->
                    </div>
                </div> */?>

        	</div> 
			 <br><h2 class="border-title aligncenter"> </h2>										 
				<div class="fullwidth-section dt-sc-parallax-section appointment-parallax dark-bg" style="background-position: 20% 3px;">
                    <div class="fullwidth-bg">
                    	<div class="parallax-spacing">
                    		<div class="container">
                            	<h3 class="border-title jmy_web_div" data-page="inicio" id="hola6" data-editor="no"><?php $this->pnt('hola6','Reserva tu cita con anticipasión');?></h3>
                                <div class="aligncenter">
                                	<a href="<?php echo RUTA_ACTUAL; ?>contacto" class="appointment-btn btn-eff2">Reserva tu  <span>cita</span></a>
                              	</div>
                            </div>
                        </div>
                   	</div>
             	</div> 				
			
            <div class="clear"></div>
            <div class="fullwidth-section promo-parallax" style="background-position: 35% 0%;">
            	<div class="parallax-spacing">
                	<div class="container">
                        <h2 class="border-title aligncenter jmy_web_div" data-page="inicio" id="hola7" data-editor="no"><?php $this->pnt('hola7','vitamina E');?></h2>
                        <div class="hr-invisible"></div>
                        <div class="column dt-sc-one-third first">
                        </div>
                        <div class="column dt-sc-one-third">
                        	<div class="animate" data-delay="200" data-animation="fadeIn animated">
	                            <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/container-box.png" alt="" title="">
                            </div>
                        </div>
                        <div class="column dt-sc-one-third">
                        	<div class="animate" data-delay="400" data-animation="fadeIn animated">
                                <h3 class="border-title jmy_web_div" data-page="inicio" id="hola8" data-editor="no">
                                    <?php $this->pnt('hola8',' Beneficios '); ?></h3>
                                <ul class="dt-sc-fancy-list check italic jmy_web_div" data-page="inicio" id="hola255" data-editor="no">
                                    <?php $this->pnt('hola255','  '); ?>
                                    <li> Es un tratamiento formulado con ampolleta en crema que restaura y fortalece tu cabello procesado inmediatamente, aumentando el tiempo del color, devolviendo la suavidad y brillo natural protegiéndolo de todo maltrato y calor dando apariencia fresca, dócil gracias a su base multivitamínica con queratina  </li>
                                   
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="hr-invisible-medium"></div>
                        <div class="column dt-sc-one-third first">
                        </div>
                        <div class="column dt-sc-two-third">
                            <div class="dt-sc-notification">
                                <div class="alignleft">
                                    <h4 class="jmy_web_div" data-page="inicio" id="hola9" data-editor="no">
                                    <?php $this->pnt('hola9','Lo puedes adquirir en nuestro Salón'); ?></h4>
                                </div>
                                <div class="alignright">
                                    <a class="dt-sc-button" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#">$160</a>
                                </div>
                            </div>
                        </div>
                        <div class="hr-invisible-very-very-small"></div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="fullwidth-section dt-sc-parallax-section counter-parallax dark-bg">
                <div class="fullwidth-bg">
                	<div class="container">
                    	<div class="hr-invisible"></div>
                    	<div class="column dt-sc-one-fourth first">
                        	<div class="dt-sc-counter animate" data-delay="100" data-animation="fadeIn animated">
                            	<div class="dt-sc-counter-number">
                                    <p data-value="250">250</p>
                                </div>
                                <div class="hr-invisible-very-small"></div>
                                <div class="hr-invisible-very-very-small"></div>
                                <img title="" alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/heading-bottom.png">
                                <div class="hr-invisible-very-small"></div>
                                <h5 class="jmy_web_div" data-page="inicio" id="hola10" data-editor="no">
                                    <?php $this->pnt('hola10','clientes'); ?></h5>
                            </div>
                        </div>
                        <div class="column dt-sc-one-fourth">
                        	<div class="dt-sc-counter animate" data-delay="200" data-animation="fadeIn animated">
                                <div class="hr-invisible-very-small"></div>
                                <h5 class="jmy_web_div" data-page="inicio" id="hola11" data-editor="no">
                                    <?php $this->pnt('hola11','estilistas'); ?></h5>
                                <div class="hr-invisible-very-small"></div>
                                <img title="" alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/heading-bottom.png">
                                <div class="hr-invisible-very-small"></div>
                                <div class="hr-invisible-very-very-small"></div>
                                <div class="dt-sc-counter-number">
                                    <p data-value="5">5</p>
                                </div>
                            </div>
                        </div>
                        <div class="column dt-sc-one-fourth">
                        	<div class="dt-sc-counter animate" data-delay="300" data-animation="fadeIn animated">
                                <div class="dt-sc-counter-number">
                                    <p data-value="150">100</p>
                                </div>
                                <div class="hr-invisible-very-small"></div>
                                <div class="hr-invisible-very-very-small"></div>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/heading-bottom.png" alt="" title="">
                                <div class="hr-invisible-very-small"></div>
                                <h5 class="jmy_web_div" data-page="inicio" id="hola12" data-editor="no" >
                                    <?php $this->pnt('hola12','comentarios'); ?></h5>
                            </div>
                        </div>
                        <div class="column dt-sc-one-fourth">
                        	<div class="dt-sc-counter animate" data-delay="400" data-animation="fadeIn animated">
                            	<div class="hr-invisible-very-small"></div>
                                <h5 class="jmy_web_div" data-page="inicio" id="hola13" data-editor="no">
                                    <?php $this->pnt('hola13','me gusta'); ?></h5>
                                <div class="hr-invisible-very-very-small"></div>
                                <div class="hr-invisible-very-very-small"></div>
                                <img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/heading-bottom.png" alt="" title="">
                                <div class="hr-invisible-very-small"></div>
                                <div class="hr-invisible-very-very-small"></div>
                                <div class="dt-sc-counter-number">
                                    <p data-value="25">25</p>
                                </div>
                            </div>
                        </div>
                        <div class="hr-invisible"></div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="hr-invisible"></div>
            <div class="container">
            	<h2 class="border-title aligncenter jmy_web_div" data-page="inicio" id="hola14" data-editor="no">
                                    <?php $this->pnt('hola14','Conoce a nuestros estilistas'); ?></h2>
                <p class="aligncenter jmy_web_div" data-page="inicio" id="hola15" data-editor="no">
                <?php $this->pnt('hola15','Cada uno de nuestros estilistas tiene la experiencia para poderlo atender y cumplir con su trabajo que ustedes deseen'); ?></p>
                <div class="hr-invisible"></div>
                <div class="column dt-sc-one-fourth first">
                    <div class="dt-sc-team type1 animate" data-delay="100" data-animation="fadeIn animated">
                        
                        <h4 class="jmy_web_div" data-page="inicio" id="hola16" data-editor="no">
                <?php $this->pnt('hola16','Alfredo'); ?></h4>
                        <h5 class="jmy_web_div" data-page="inicio" id="hola17" data-editor="no">
                <?php $this->pnt('hola17','estilista en general'); ?></h5>
						<h5 class="jmy_web_div" data-page="inicio" id="hola18" data-editor="no">
                <?php $this->pnt('hola18','cambio de color'); ?></h5>
						 <h5 class="jmy_web_div" data-page="inicio" id="hola19" data-editor="no">
                <?php $this->pnt('hola19','barbas'); ?></h5>
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                    <div class="dt-sc-team type1 animate" data-delay="200" data-animation="fadeIn animated">
                        
                        <h4 class="jmy_web_div" data-page="inicio" id="hola20" data-editor="no">
                <?php $this->pnt('hola20','Esmeralda'); ?></h4>
                        <h5 class="jmy_web_div" data-page="inicio" id="hola21" data-editor="no">
                <?php $this->pnt('hola21','estilista en general'); ?></h5>
						 <h5 class="jmy_web_div" data-page="inicio" id="hola22" data-editor="no">
                <?php $this->pnt('hola22','uñas de acrílico'); ?></h5>
						  <h5 class="jmy_web_div" data-page="inicio" id="hola23" data-editor="no">
                <?php $this->pnt('hola23','manicurista'); ?></h5>
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                    <div class="dt-sc-team type1 animate" data-delay="300" data-animation="fadeIn animated">
                        
                        <h4 class="jmy_web_div" data-page="inicio" id="hola24" data-editor="no">
                <?php $this->pnt('hola24','Aida'); ?></h4>
                        <h5 class="jmy_web_div" data-page="inicio" id="hola25" data-editor="no">
                <?php $this->pnt('hola25','estilista en general'); ?></h5>
						 <h5 class="jmy_web_div" data-page="inicio" id="hola26" data-editor="no">
                <?php $this->pnt('hola26','Maniculista'); ?></h5>
						  <h5 class="jmy_web_div" data-page="inicio" id="hola27" data-editor="no">
                <?php $this->pnt('hola27',''); ?></h5>
						
                    </div>
                </div>
                <div class="column dt-sc-one-fourth">
                    <div class="dt-sc-team type1 animate" data-delay="400" data-animation="fadeIn animated">
                        
                        <h4 class="jmy_web_div" data-page="inicio" id="hola28"data-editor="no">
                <?php $this->pnt('hola28','Beatris'); ?></h4>
                        <h5 class="jmy_web_div" data-page="inicio" id="hola29"data-editor="no">
                <?php $this->pnt('hola29','estilista en general'); ?></h5>
						 <h5 class="jmy_web_div" data-page="inicio" id="hola30"data-editor="no">
                <?php $this->pnt('hola30','manicurista'); ?></h5>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="hr-invisible-medium"></div>
          	<div class="fullwidth-section dt-sc-parallax-section blog-parallax dark-bg">
                <div class="fullwidth-bg">
                	<div class="parallax-spacing">
                    	<div class="container">
                        	<h2 class="border-title aligncenter jmy_web_div" data-page="inicio" id="hola31"data-editor="no">
                <?php $this->pnt('hola31','servicios'); ?></h2>
                            <div class="hr-invisible"></div>
                            <div class="column dt-sc-one-third first">
                            	<article class="blog-entry">
                                    <div class="entry-thumb">
                                    	<a href="<?php echo RUTA_ACTUAL; ?>">
                                        	<img title="" alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/blog-img1.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-details">
                                        <div class="hr-invisible-very-small"></div>
                                        <div class="entry-title">
	                                        <h3 class="jmy_web_div" data-page="inicio" id="hola32"data-editor="no">
                <?php $this->pnt('hola32','Manicure'); ?></h3>
	                                       
                                        </div>
                                       
                <div class="entry-metadata">
                <p class="jmy_web_div" data-page="inicio" id="hola33"data-editor="no">
                <?php $this->pnt('hola33','Ven a consentir tus manos y relajarse'); ?></p>
                 <div class="author">
                <i class="fa fa-clock-o jmy_web_div" data-page="inicio" id="hola34"data-editor="no">
                <?php $this->pnt('hola34','40 minutos'); ?></i>
                 
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tag jmy_web_div" data-page="inicio" id="hola35"data-editor="no">
                <?php $this->pnt('hola35',' 100'); ?></i>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="column dt-sc-one-third">
                            	<article class="blog-entry">
                                    <div class="entry-thumb">
                                    	<a href="<?php echo RUTA_ACTUAL; ?>">
                                        	<img title="" alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/blog-img2.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-details">
                                        <div class="hr-invisible-very-small"></div>
                                        <div class="entry-title">
	                                        <h3 class="jmy_web_div" data-page="inicio" id="hola36"data-editor="no">
                <?php $this->pnt('hola36','tratamientos capilares'); ?></h3>
                                        </div>
                                       
            <div class="entry-metadata">
            <p class="jmy_web_div" data-page="inicio" id="hola37"data-editor="no">
            <?php $this->pnt('hola37','ven y cuida tu cabello con productos adecuados para tu cabello'); ?></p>
            <div class="author">
            <i class="fa fa-clock-o jmy_web_div" data-page="inicio" id="hola38"data-editor="no">
            <?php $this->pnt('hola38','1 hrs'); ?></i>
            </div>
            <div class="tags">
            <i class="fa fa-tag jmy_web_div" data-page="inicio" id="hola39"data-editor="no">
                <?php $this->pnt('hola39','desde 150'); ?></i>
            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <div class="column dt-sc-one-third">
                            	<article class="blog-entry">
                                    <div class="entry-thumb">
                                    	<a href="<?php echo RUTA_ACTUAL; ?>">
                                        	<img title="" alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/blog-img3.jpg">
                                        </a>
                                    </div>
                                    <div class="entry-details">
                                        <div class="hr-invisible-very-small"></div>
                                        <div class="entry-title">
	                                        <h3 class="jmy_web_div" data-page="inicio" id="hola40"data-editor="no">
                <?php $this->pnt('hola40','uñas y gelish'); ?></h3>
                                        </div>
                                      
                                        <div class="entry-metadata">
                                            <p class="jmy_web_div" data-page="inicio" id="hola41"data-editor="no">
                <?php $this->pnt('hola41','ven a ponerte uñas de acrílico y gelish para esa ocasión especial'); ?></p>
                                            <div class="author">
                                                <i class="fa fa-clock-o jmy_web_div" data-page="inicio" id="hola42"data-editor="no">
                <?php $this->pnt('hola42','1 hrs'); ?></i>
                                                
                                            </div>
                                            <div class="tags">
                                                <i class="fa fa-tag jmy_web_div" data-page="inicio" id="hola43"data-editor="no">
                <?php $this->pnt('hola43','desde 120'); ?></i>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
               	</div>
          	</div>
            <div class="clear"></div>
            <div class="hr-invisible"></div>
            <h2 class="border-title aligncenter jmy_web_div" data-page="inicio" id="hola44"data-editor="no">
                <?php $this->pnt('hola44','lista de precios y servicios'); ?></h2>
         	<div class="hr-invisible"></div>
            <div class="fullwidth-section pricing-container">
            <div class="left-image"></div>
            	<div class="container">
                    <div class="column dt-sc-two-fifth first">
                        <h1 class="alignright"> <br><span></span> </h1>
                    </div>
                    <div class="column dt-sc-three-fifth">
                        <div class="dt-sc-pricing-carousel-wrapper">
                            <div class="dt-sc-pricing-carousel">
                                <div class="column dt-sc-one-half">
                                    <ul class="menu-card check">
                                        <li class="jmy_web_div" data-page="inicio" id="hola45"data-editor="no">
                                    <?php $this->pnt('hola45','corte de dama '); ?>
                                        <span>$120</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola46"data-editor="no">
                                     <?php $this->pnt('hola46','corte de niña '); ?><span>$120</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola47"data-editor="no">
<?php $this->pnt('hola47','sedado y Planchado desde '); ?><span>$120</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola48"data-editor="no">
<?php $this->pnt('hola48','Manicure '); ?><span>$100</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola49"data-editor="no">
<?php $this->pnt('hola49','Pedicure '); ?><span>$140</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola50"data-editor="no">
<?php $this->pnt('hola50','Esmaltado '); ?><span>$60</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola51"data-editor="no">
<?php $this->pnt('hola51','Esmalte 21 angel '); ?><span>$100</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola52"data-editor="no">
<?php $this->pnt('hola52','Esmalte 21 mishel'); ?><span>$150</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola53"data-editor="no">
<?php $this->pnt('hola53','Gelish'); ?><span>$180</span></li>
										<li class="jmy_web_div" data-page="inicio" id="hola54"data-editor="no">
<?php $this->pnt('hola54','Rizado de pestañas'); ?><span>$150</span></li>
                                    </ul>
                                </div>
                                <div class="column dt-sc-one-half">
                                    <ul class="menu-card check">
                                        <li class="jmy_web_div" data-page="inicio" id="hola55"data-editor="no">
<?php $this->pnt('hola55','corte de caballero '); ?><span>$100</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola56"data-editor="no">
<?php $this->pnt('hola56','corte de niño '); ?><span>$100</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola57"data-editor="no">
<?php $this->pnt('hola57','barba '); ?><span>$100</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola58"data-editor="no">
<?php $this->pnt('hola58','Planchado de ceja'); ?><span>$150</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola59"data-editor="no">
<?php $this->pnt('hola59','extenciones desde'); ?><span>$1800</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola60"data-editor="no">
<?php $this->pnt('hola60','tintes desde'); ?><span>$350</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola61"data-editor="no">
<?php $this->pnt('hola61','A/tinte desde '); ?><span>$150</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola62"data-editor="no">
<?php $this->pnt('hola62','rayos desde  '); ?><span>$380</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola63"data-editor="no">
<?php $this->pnt('hola63','efectos de color desde '); ?><span>$450</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola64"data-editor="no">
<?php $this->pnt('hola64','tratamientos capilar desde  '); ?><span>$150</span></li>
                                    </ul>
                                </div>
                                <div class="column dt-sc-one-half">
                                    <ul class="menu-card check">
                                        <li class="jmy_web_div" data-page="inicio" id="hola65"data-editor="no">
<?php $this->pnt('hola65','depilaciones '); ?><span></span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola66"data-editor="no">
<?php $this->pnt('hola66','axila desde '); ?><span>$50</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola67"data-editor="no">
<?php $this->pnt('hola67','ceja desde '); ?><span>$50</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola68"data-editor="no">
<?php $this->pnt('hola68','bozo desde '); ?><span>$50</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola69"data-editor="no">
<?php $this->pnt('hola69','piernas desde '); ?><span>$150</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola70"data-editor="no">
<?php $this->pnt('hola70','rostro desde '); ?><span>$150</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola71"data-editor="no">
<?php $this->pnt('hola71','uñas de acrílico desde '); ?><span>$120</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola72"data-editor="no">
<?php $this->pnt('hola72','beses desde  '); ?><span>$350</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola73"data-editor="no">
<?php $this->pnt('hola73','.'); ?><span>$</span></li>
                                        <li class="jmy_web_div" data-page="inicio" id="hola74"data-editor="no">
<?php $this->pnt('hola74','.'); ?><span>$</span></li>
                                    </ul>
                                </div>
                                
                            </div>
                            <div class="carousel-arrows">
                                <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="pricing prev-arrow"><i class="fa fa-angle-left"></i></a>
                                <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="pricing next-arrow"><i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="clear"></div>
            <div class="hr-invisible"></div>
            <div class="container">
            	<h2 class="border-title aligncenter"> Client Testimonials </h2>
                <div class="dt-sc-testimonial-carousel-wrapper">
                    <ul class="dt-sc-testimonial-carousel">
                        <li>
                        	<div class="dt-sc-testimonial"> 
                            	<div class="author">
	                                <img alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/testimonial-img1.jpg">
                                </div>
                                <div class="hr-invisible-small"></div>
                                <blockquote> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut <br>labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat uis aute irure dolor </blockquote>
                                <div class="author-detail">
                                	Jos Buttler <span>Duis aute irure</span>
                                </div>
                            </div>
                        </li>
                        <li>
                        	<div class="dt-sc-testimonial"> 
                            	<div class="author">
	                                <img alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/testimonial-img2.jpg">
                                </div>
                                <div class="hr-invisible-small"></div>
                                <blockquote> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut <br>labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat uis aute irure dolor </blockquote>
                                <div class="author-detail">
                                	Sarah Taylor <span>Duis aute irure</span>
                                </div>
                            </div>
                        </li>
                        <li>
                        	<div class="dt-sc-testimonial"> 
                            	<div class="author">
	                                <img alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/testimonial-img3.jpg">
                                </div>
                                <div class="hr-invisible-small"></div>
                                <blockquote> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut <br>labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat uis aute irure dolor </blockquote>
                                <div class="author-detail">
                                	Lydia Greenway <span>Duis aute irure</span>
                                </div>
                            </div>
                        </li>
                        <li>
                        	<div class="dt-sc-testimonial"> 
                            	<div class="author">
	                                <img alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/testimonial-img4.jpg">
                                </div>
                                <div class="hr-invisible-small"></div>
                                <blockquote> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut <br>labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat uis aute irure dolor </blockquote>
                                <div class="author-detail">
                                	Steve Smith <span>Duis aute irure</span>
                                </div>
                            </div>
                        </li>
                        <li>
                        	<div class="dt-sc-testimonial"> 
                            	<div class="author">
	                                <img alt="" src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/testimonial-img2.jpg">
                                </div>
                                <div class="hr-invisible-small"></div>
                                <blockquote> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut <br>labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat uis aute irure dolor </blockquote>
                                <div class="author-detail">
                                	Sarah Taylor <span>Duis aute irure</span>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="carousel-arrows">
                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="carousel-prev"></a>
                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="carousel-next"></a>
                    </div>
              	</div>  
                <div class="clear"></div>  
            </div>
            <div class="clear"></div>
       		<div class="hr-invisible"></div> 
     	</div><!-- End of Main --> 
		<div class="container">
		&nbsp;
  
</div>