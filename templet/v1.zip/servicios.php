       <div id="main"><!-- Main -->
        	<div class="hr-invisible-small"></div>
        	<section class="fullwidth-background">
        		<div class="breadcrumb-wrapper">
                    <div class="container">
                        <h4 class="jmy_web_div" data-page="servicios" id="hola78"data-editor="no">
<?php $this->pnt('hola78','Nuestros servicios '); ?>
</h4>
                        
                    </div>
                </div>                
            </section>
            <div class="hr-invisible-very-small"></div>
            <div class="clear"></div>
            <section id="primary" class="content-full-width"><!-- Primary Section -->
            	<div class="fullwidth-section">
                    <h2 class="border-title aligncenter jmy_web_div" data-page="servicios" id="hola79"data-editor="no">
<?php $this->pnt('hola79','Nuestros servicios de salón '); ?>
</h2>
        <div class="dt-sc-tabs-container">
            <div class="clear"></div>
            <div class="hr-invisible-small"></div>
        <ul class="dt-sc-tabs-frame">	
            <li class="btn-eff3 current jmy_web_div" data-page="servicios" id="hola80"data-editor="no">
            <?php $this->pnt('hola80','cortes y barbas '); ?>
            </li>
            <li class="btn-eff3 jmy_web_div" data-page="servicios" id="hola81"data-editor="no">
            <?php $this->pnt('hola81','secados y planchados '); ?>
            </li>
            <li class="btn-eff3 jmy_web_div" data-page="servicios" id="hola82"data-editor="no">
<?php $this->pnt('hola82','tintes,mechas y tratamientos '); ?>
</li>
            <li class="btn-eff3 jmy_web_div" data-page="servicios" id="hola83"data-editor="no">
<?php $this->pnt('hola83','uñas, manicure y pedicure '); ?>
</li>
        </ul>  
                <div class="clear"></div>
                <div class="hr-invisible"></div>
                <div class="fullwidth-section dt-sc-parallax-section appointment-parallax dark-bg" style="background-position: 20% 3px;">
                    <div class="fullwidth-bg">
                    	<div class="parallax-spacing">
                    		<div class="container">
                            	<h3 class="border-title jmy_web_div" data-page="servicios" id="hola84"data-editor="no">
<?php $this->pnt('hola84','Reserva tu cita con anticipación '); ?>
</h3>
                                <div class="aligncenter">
                                	<a href="<?php echo RUTA_ACTUAL; ?>contacto" class="appointment-btn btn-eff2 jmy_web_div" data-page="servicios" id="hola85"data-editor="no">
<?php $this->pnt('hola85','Reserva tu cita  '); ?>
</a>
                              	</div>
                            </div>
                        </div>
                   	</div>
             	</div> 						
                        <div class="hr-invisible"></div>                         
                        <div class="dt-sc-tabs-frame-content">
                        	<div class="alignleft">
                            	<div class="services-container alignright">
                                	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-tab-img1.jpg" alt="" title="" >
                                    <div class="dt-sc-view-btn">
                                    	<a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="btn-eff2 jmy_web_div" data-page="servicios" id="hola86" data-editor="no">
<?php $this->pnt('hola86',' ver galería'); ?>
</a>
                                    </div>
									<div class="alignright"></div>
									<ul class="dt-sc-fancy-list check">
									 </ul>
                                    <div class="text-align=alignright">
                                        <h3 class="alignright jmy_web_div" data-page="servicios" id="hola87" data-editor="no">
<?php $this->pnt('hola87','para ellos'); ?>
</h3>
										 <br>
										 <br>
										 <br>
                                       
                                        <ul class="alignright jmy_web_div" data-page="servicios" id="hola88"data-editor="no">
                 <?php $this->pnt('hola88','<li> Corte de cabello </li>
                                            <li> Barba </li>
                                            <li> Tinte </li>
                                            <li> Manicure</li>
                                            <li> Pedicure </li>
                                            <li> Rasurada </li>'); ?>

                                        
                                            
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="alignright">
                            	<div class="services-container alignright">
                                	<img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/service-tab-img2.jpg" alt="" title="" >
                                    <div class="dt-sc-view-btn">
                                    	<a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="btn-eff2 jmy_web_div" data-page="servicios" id="hola89"data-editor="no">
<?php $this->pnt('hola89','ver galería'); ?>
</a>
                                    </div>
                                    <div class="text-align=center">
                                        <h3 class="jmy_web_div" data-page="servicios" id="hola90"data-editor="no">
<?php $this->pnt('hola90','para ellas '); ?>
</h3>
                                        
                                        <ul class="alignleft jmy_web_div" data-page="servicios" id="hola91"data-editor="no">
<?php $this->pnt('hola91','  li> corte de cabello </li>
                                            <li> Depilaciones </li>
                                            <li> Maquillaje </li>
                                            <li> Peinados </li>
                                            <li> Manicure y pedicure  </li>
                                            <li> Tintes </li>
                                            <li> Rayos y mechas   </li>
                                            <li> Pestañas  </li>
                                            <li> uñas</li>
                                            <li> gelish  </li>
                                            <li> tratamientos capilares</li>'); ?>

                                            
                                        </ul>
                                    </div>
                                </div>	
                            </div>
                        </div>
                        <br>
									
                    </div>
                </div>
                <div class="clear"></div>
                <div class="hr-invisible"></div>
                <?php /* <div class="fullwidth-section dt-sc-parallax-section pricing-parallax dark-bg">
                    <div class="fullwidth-bg">
                        <div class="parallax-spacing">
                             <div class="container"><!-- Container -->
                        	<h2 class="border-title aligncenter"> Nuestras ofertas </h2>
                            <div class="hr-invisible-small"></div>
                            <div class="column dt-sc-one-fourth first">
                            	<div class="animate" data-delay="200" data-animation="fadeIn animated">
                                    <h3 class="border-title">Sal&oacuten<span>  Evolution</span></h3>
                                    <p>Aproveche las ofertas .</p>
                                    <div class="dt-sc-offer-text">
                                        <h2>50</h2>
                                        <span>%<span>off</span></span>
                                    </div>
                                    <div class="clear"></div>
                                    <ul class="dt-sc-offer-date">
                                        <li>
                                            <span class="fa fa-calendar"></span>
                                            Martes 24 de octubre 
                                        </li>
                                        <li>
                                            <span class="fa fa-map-marker"></span>
                                            ubicación
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="column dt-sc-three-fourth">
                            	<div class="dt-sc-offer-carousel-wrapper animate" data-delay="400" data-animation="fadeIn animated">
                                	<div class="dt-sc-offer-carousel">
                                    	<div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img1.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">Mechas californianas</a></h4>
                                                    <div class="dt-sc-price">
                                                    	$ 600
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL; ?>" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">corte en capas</a></h4>
                                                    <div class="dt-sc-price">
                                                    	2x1
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL; ?>" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL; ?>"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/blog-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL; ?>">tratamientos</a></h4>
                                                    <div class="dt-sc-price">
                                                    	$ 1200
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" data-text="View Details"><span>Detalles</span></a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="column dt-sc-one-third">
                                        	<div class="dt-sc-offer">
                                                <figure class="gallery-thumb">
                                                    <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#"><img src="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>images/offer-img2.jpg" alt="" title=""></a>
                                                </figure>
                                                <div class="gallery-details">
                                                	<h4><a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#">Hair Coloring</a></h4>
                                                    <div class="dt-sc-price">
                                                    	£ 200
                                                    </div>
                                                    <div class="hr-invisible-very-very-small"></div>
                                                    <a class="dt-sc-button btn-eff3" href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" data-text="View Details"><span>View Details</span></a>
                                                </div>
                                            </div>
                                        </div>
	                                </div>
                                	<div class="carousel-arrows">
                                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="prev-arrow"><i class="fa fa-angle-left"></i></a>
                                        <a href="<?php echo RUTA_ACTUAL.BASE_TEMPLET; ?>#" class="next-arrow"><i class="fa fa-angle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="hr-invisible-small"></div>
                            <div class="hr-invisible-very-small"></div>
                        </div><!-- End of Container -->
                        </div>
                    </div>
            	</div>  */?>
                <div class="clear"></div>
                <div class="hr-invisible"></div>
                
                <div class="hr-separator type2"></div>
                
              
            </section><!-- End of Primary Section -->   
        </div><!-- End of Main -->