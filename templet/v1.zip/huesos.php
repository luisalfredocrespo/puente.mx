<?php 


echo "huesos";
?>